#
#<?php die('Forbidden.'); ?>
#Date: 2016-10-19 06:08:14 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2016-10-19T06:08:14+00:00	INFO 81.196.107.209	update	Update started by user Super User (754). Old version is 3.6.2.
2016-10-19T06:08:15+00:00	INFO 81.196.107.209	update	Downloading update file from https://github.com/joomla/joomla-cms/releases/download/3.6.3/Joomla_3.6.3-Stable-Update_Package.zip.
2016-10-19T06:08:19+00:00	INFO 81.196.107.209	update	File Joomla_3.6.3-Stable-Update_Package.zip successfully downloaded.
2016-10-19T06:08:19+00:00	INFO 81.196.107.209	update	Starting installation of new version.
2016-10-19T06:08:38+00:00	INFO 81.196.107.209	update	Finalising installation.
2016-10-19T06:08:38+00:00	INFO 81.196.107.209	update	Ran query from file 3.6.3-2016-08-15. Query text: ALTER TABLE `#__newsfeeds` MODIFY `link` VARCHAR(2048) NOT NULL;.
2016-10-19T06:08:38+00:00	INFO 81.196.107.209	update	Ran query from file 3.6.3-2016-08-16. Query text: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2016-10-19T06:08:38+00:00	INFO 81.196.107.209	update	Deleting removed files and folders.
2016-10-19T06:08:39+00:00	INFO 81.196.107.209	update	Cleaning up after installation.
2016-10-19T06:08:39+00:00	INFO 81.196.107.209	update	Update to version 3.6.3 is complete.
