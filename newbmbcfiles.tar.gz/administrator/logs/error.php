#
#<?php die('Forbidden.'); ?>
#Date: 2016-10-17 05:45:18 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2016-10-17T05:45:18+00:00	INFO 81.196.107.209	joomlafailure	Empty password not allowed.
2016-10-19T07:01:04+00:00	INFO 81.196.107.209	joomlafailure	Empty password not allowed.
